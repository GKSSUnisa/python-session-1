#Create a user programm ask the for the name and surname ask for the age

#variables  #input function
first_name = input("Enter your name: ")
surname = input("Enter your surname: ")
age = input("Enter your age: ")

#print function
print("Your name is:" ,first_name)
print("Your name is:" ,surname)
print("Your name is:" ,age)

