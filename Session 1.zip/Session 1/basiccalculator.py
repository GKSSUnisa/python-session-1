#calculations using if-statements

#ask the user for 2 numbers

number1 = int(input("Enter first number: \n"))
number2 = int(input("Enter second number: \n"))

answer=input(" Choose option: \n a) Addtion \n b) Subraction \n c) Multiplication \n d) Division \n")

#if-statments

#for addtion
if answer == "a":
    print(number1 + number2)

#for subraction
if answer == "b":
    print(number1 - number2)

#for multiplication
if answer == "c":
    print(number1 * number2)

#for addtion
if answer == "d":
    print(number1 / number2)
