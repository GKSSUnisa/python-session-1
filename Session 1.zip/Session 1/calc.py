#basic calculations

#asking for the firdt 2 numbers
number1 = int(input("Enter first number: \n"))
number2 = int(input("Enter first number: \n"))


#multiplication

print("multiplication:" , number1 * number2 )

#subrtaction
print("subrtaction:" , number1 - number2 )

#addtion
print("addtion:" , number1 + number2 )

#division
print("division:" , number1 / number2 )
